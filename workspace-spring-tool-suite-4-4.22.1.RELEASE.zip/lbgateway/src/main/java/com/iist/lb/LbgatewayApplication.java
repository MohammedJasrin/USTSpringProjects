package com.iist.lb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LbgatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(LbgatewayApplication.class, args);
	}

}
