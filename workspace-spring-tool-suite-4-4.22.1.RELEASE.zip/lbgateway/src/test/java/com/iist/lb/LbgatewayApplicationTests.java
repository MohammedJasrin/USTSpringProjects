package com.iist.lb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LbgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
